classdef myfit < RegFit.fitModel
    
end